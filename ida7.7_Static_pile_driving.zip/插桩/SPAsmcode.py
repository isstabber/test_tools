X64_cell_size = 8
X86_cell_size = 4
def X64_asm(num,func):
    Argv_regs = f"""
                push rax
                push rdi
                push rsi
                push rdx
                push rcx
                push r8
                push r9
                push r10

                push rsp
                pop rsi
                mov rax, 1
                mov rdi, 1
                mov rdx, {hex(X64_cell_size*num)}
                syscall

                pop r10
                pop r9
                pop r8
                pop rcx
                pop rdx
                pop rsi
                pop rdi
                pop rax
                """
    All_regs = f"""
                push rax
                push rbx
                push rcx
                push rdx
                push rdi
                push rsi
                push r8
                push r9
                push r10
                push r11
                push r12
                push r13
                push r14
                push r15

                push rsp
                pop rsi
                mov rax, 1
                mov rdi, 1
                mov rdx, {hex(X64_cell_size*num)}
                syscall

                pop r15
                pop r14
                pop r13
                pop r12
                pop r11
                pop r10
                pop r9
                pop r8
                pop rsi
                pop rdi
                pop rdx
                pop rcx
                pop rbx
                pop rax

                """
    Ret_value = f"""
               push rdi
               push rdx
               push rsi
               push rax

               push rsp
               pop rsi
               mov rax, 1
               mov rdi, 1
               mov rdx, {hex(X64_cell_size*num)}
               syscall

               pop rax   
               pop rsi
               pop rdx
               pop rdi
               """
    Sleep = f'''
                push rdi
                push rax
                push rsi

                push 0x23
                pop rax
                push 0
                push {hex(num)}
                push rsp
                pop rdi
                xor rsi,rsi
                syscall

                pop rax
                pop rax
                pop rsi
                pop rax
                pop rdi
                '''
    if func == "Argv_regs":#, "Ret_value", "Argv_regs"
        asm = Argv_regs
    elif func == "Ret_value":
        asm =  Ret_value
    elif func == "All regs":
        asm = All_regs
    elif func == "sleep":
        asm = Sleep
    return asm

def X86_asm(num,func):
    Argv_regs = f"""
                push esp
                push ecx
                mov ecx,dword ptr [esp+4]
                push eax
                push ebx
                push edx
                push 4
                pop eax
                push 1
                pop ebx
                push {hex(X86_cell_size*num)}
                pop edx
                int 0x80
                
                pop edx
                pop ebx
                pop eax
                pop ecx
                pop esp
                """
    All_regs = f"""
                push eax
                push ebx
                push ecx
                push edx
                push edi
                push esi
                push esp
                pop ecx
                
                push 1
                pop ebx
                push 4
                pop eax
                push {hex(X86_cell_size*num)}
                pop edx
                int 0x80
                
                pop esi
                pop edi
                pop edx
                pop ecx
                pop ebx
                pop eax

                """
    Ret_value = f"""
                push ecx
                mov ecx,eax
                push eax
                push ebx
                push edx
                
                
                push 4
                pop eax
                push 1
                pop ebx
                push {hex(X86_cell_size*num)}
                pop edx
                int 0x80 
                
                pop edx
                pop ebx
                pop eax
                pop ecx
"""
    Sleep = f'''
                push eax
                push ebx
                push ecx
                
                push 0xa2
                pop eax
                push 0
                push {hex(num)}
                push esp
                pop ebx
                xor ecx,ecx
                int 0x80
                
                pop ecx
                pop ecx
                pop ecx
                pop ebx 
                pop eax
                '''
    if func == "Argv_regs":#, "Ret_value", "Argv_regs"
        asm = Argv_regs
    elif func == "Ret_value":
        asm =  Ret_value
    elif func == "All regs":
        asm = All_regs
    elif func == "sleep":
        asm = Sleep
    return asm