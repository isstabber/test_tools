import idaapi
from idautils import *

from idc import *



class Menu_Context(idaapi.action_handler_t):

    @classmethod
    def get_name(self):
        return self.__name__

    @classmethod
    def get_label(self):
        return self.label

    @classmethod
    def register(self, plugin, label):   #lable 标签，就是调用时给的字符串          Kp_pr_addr
        #print("-self--<< {} >>----register_plugin->> {} <<-->>{} <<--".format(self,plugin,label))
        self.plugin = plugin
        self.label = label
        instance = self()
       # print("-instance ---------- {} --------".format(self()))
        return idaapi.register_action(idaapi.action_desc_t(
            self.get_name(),  # Name. Acts as an ID. Must be unique.
            instance.get_label(),  # Label. That's what users see.
            instance  # Handler. Called when activated, and for updating     Kp_pr_addr.Myplug.activated()

        ))

    @classmethod
    def unregister(self):

        idaapi.unregister_action(self.get_name())

    @classmethod
    def activate(self, ctx):
        # dummy method
        return 1

    @classmethod
    def update(self, ctx):
        try:
            if ctx.form_type == idaapi.BWN_DISASM:
                return idaapi.AST_ENABLE_FOR_FORM
            else:
                return idaapi.AST_DISABLE_FOR_FORM
        except Exception as e:
            # Add exception for main menu on >= IDA 7.0
            return idaapi.AST_ENABLE_ALWAYS

class Sp_Pr_Reg(Menu_Context):
    #通过菜单调用
    def activate(self, ctx):
        try:
            self.plugin.pri_reg()

        except:
            self.plugin.print_current_address()
            print("An error occurred while executing the pri function.")
        return 1
class Sp_sleep(Menu_Context):
    def activate(self, ctx):
        try:
            self.plugin.slep()

        except:
            self.plugin.print_current_address()
            print("An error occurred executing the sleep function.")
        return 1
class Sp_custom_pile(Menu_Context):
    def activate(self, ctx):
        try:
            self.plugin.Custom_pile_code()

        except:
            self.plugin.print_current_address()
            print("An error occurred while executing a custom function.")
        return 1

