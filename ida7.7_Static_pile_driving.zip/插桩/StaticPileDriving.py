
import idaapi
from idautils import *
from keystone import *
from idc import *
import SPMenu
import SPUtils
import  SPForm
from SPAsmcode import *





class Static_pile_driving(idaapi.plugin_t):
    flags = 0
    comment = "Static pile plug-in"
    help = "This is help"
    wanted_name = "Static_pile_driving"
    wanted_hotkey = "Ctrl-Alt-Q"

    MENU_ENTRY_PRINT_CURRENT_ADDRESS = "Static_pile_driving:Print register"

    def init(self):
        idaapi.msg("Static pile plug-in loaded--------------------------------\n")
        try:
            global base_addr
            base_addr = idaapi.get_imagebase()
            file_path = get_input_file_path()
            print(f"file_path is {file_path}")

        except Exception:
            print("Failed to obtain the file path or arch!")
            pass

        try:

            SPMenu.Sp_Pr_Reg.register(self,"Print register")
            SPMenu.Sp_sleep.register(self, "Sleep a few seconds")
            SPMenu.Sp_custom_pile.register(self, "Custom pile code")
        except:
            print("reg fail--------------------------")
            pass
        self.ArchSpec = SPUtils.SP_ArchSpec()

        idaapi.attach_action_to_menu("Edit/Static_pile_driving/", SPMenu.Sp_Pr_Reg.get_name(), idaapi.SETMENU_APP)
        idaapi.attach_action_to_menu("Edit/Static_pile_driving/", SPMenu.Sp_sleep.get_name(), idaapi.SETMENU_APP)
        idaapi.attach_action_to_menu("Edit/Static_pile_driving/", SPMenu.Sp_custom_pile.get_name(), idaapi.SETMENU_APP)
        return idaapi.PLUGIN_KEEP
#通过快捷键调用
    def run(self, arg):
        idaapi.msg("Static pile plug-in executed\n")
        self.pri_reg()

    def term(self):
        idaapi.msg("Static pile plug-in terminated\n")
        idaapi.detach_action_from_menu("Edit/", self.MENU_ENTRY_PRINT_CURRENT_ADDRESS)
        idaapi.unregister_action(self.MENU_ENTRY_PRINT_CURRENT_ADDRESS)



    def print_current_address(self):
        ea = idaapi.get_screen_ea()
        idaapi.msg("Current address: 0x{:X}\n".format(ea))

    def pri_reg(self):
        try:
            dlg = SPForm.MethodSelectionDialog()
            if dlg.Execute() == 1:
                method = dlg.get_selected_method()
            if self.ArchSpec.mode == KS_MODE_64 :
                if method == "Argv_regs":  # , "Ret_value", "Argv_regs"
                    size = 8
                elif method == "All regs":
                    size = 14
                elif method == "Ret_value":
                    size = 1
                #second
                asm_code = X64_asm(size,method)
            elif self.ArchSpec.mode == KS_MODE_32:
                if method == "Argv_regs":  # , "Ret_value", "Argv_regs"         #32位下默认是打印了栈中的参数，打印字节数为6个内存单元
                    size = 6
                elif method == "All regs":
                    size = 6
                elif method == "Ret_value":
                    size = 1
                asm_code = X86_asm(size,method)
            SPUtils.utils.x64_pile_driver(asm_code,SP_ArchSpec = self.ArchSpec)

        except Exception as e:
            print(f"An error when the register code is inserted : {e}")

    def slep(self):
        try:
            dlg = SPForm.NumberInputDialog()
            if dlg.Execute() == 1:
                time = dlg.get_number()
            if self.ArchSpec.mode == KS_MODE_64 :
                #second
                asm_code = X64_asm(time,"sleep")
            elif self.ArchSpec.mode == KS_MODE_32:
                asm_code = X86_asm(time,"sleep")
            SPUtils.utils.x64_pile_driver(asm_code,SP_ArchSpec = self.ArchSpec)
        except Exception as e:
            print(f"An error in inserting sleep code : {e}")

    def Custom_pile_code(self):
        try:
            dlg = SPForm.AsmCodeInputDialog()
            if dlg.Execute() == 1:
                asm_code = SPUtils.utils.check_asm_code(dlg.get_asm_code())  # 获取用户输入的代码
                SPUtils.utils.x64_pile_driver(asm_code,SP_ArchSpec = self.ArchSpec)
        except Exception as e:
            print(f"An error in custom pile code : {e}")
            pass


def PLUGIN_ENTRY():
    return Static_pile_driving()
