import idaapi
from idautils import *

from idc import *
class MethodSelectionDialog(idaapi.Form):
    def __init__(self):
        super(MethodSelectionDialog, self).__init__(
            r"""STARTITEM 0
BUTTON YES* OK
BUTTON CANCEL Cancel
Static pile::pr reg
Select the method:
            <method : {method}>
            """,
        {
            'method': idaapi.Form.DropdownListControl(
                items=["All regs", "Ret_value", "Argv_regs"],  # 下拉菜单选项
                readonly=True,  # 设置为只读，用户不能输入其他内容
                selval=0  # 默认选中的选项，0表示第一个（All regs）
            )
        }
        )

        self.Compile()


    def get_selected_method(self):
        method_map = {0: "All regs", 1: "Ret_value", 2: "Argv_regs"}
        return method_map[self.method.value]


class NumberInputDialog(idaapi.Form):
    def __init__(self):
        # 初始化表单控件
        super(NumberInputDialog, self).__init__(
            r"""STARTITEM 0
BUTTON YES* OK
BUTTON CANCEL Cancel
Static pile::Sleep
Input sleep seconds:
        <second:{iNumber}>
        """, {
            'iNumber': idaapi.Form.NumericInput(value=0, swidth=10)
        })
        self.Compile()

    # 获取用户输入的数字
    def get_number(self):
        return self.iNumber.value




class AsmCodeInputDialog(idaapi.Form):
    def __init__(self):

        # 初始化表单控件
        super(AsmCodeInputDialog, self).__init__(
            r"""STARTITEM 0
BUTTON YES* OK
BUTTON CANCEL Cancel
Static pile::Custom Assembly
            <Enter Assembly Code:{iCode}>
            """, {
            'iCode': idaapi.Form.MultiLineTextControl(text="")
        })

        self.Compile()

    def get_asm_code(self):
        return self.iCode.value