import idaapi
from idautils import *
import ida_ua
from keystone import *
import re
from idc import *

class SP_ArchSpec:
    def __init__(self,arch = None,mode = None):
        self.arch , self.mode = self.get_hard_archspec()
        if arch is not None:
            self.arch = arch
        if mode is not None:
            self.mode = mode
        self.syntax = KS_OPT_SYNTAX_INTEL
    @staticmethod
    def get_hard_archspec():
        (arch,mode) = (None,None)

        info = idaapi.get_inf_structure()


        cpuname = info.procname.lower()
        if cpuname == "metapc":
            arch = KS_ARCH_X86
            if info.is_64bit():
                mode = KS_MODE_64
            elif info.is_32bit():
                mode = KS_MODE_32
            else:
                mode = KS_MODE_16
        return (arch,mode)

class utils():
    @staticmethod
    def check_asm_code(asm_code):
        tmp = ""
        try:
            asm_lines = asm_code.splitlines()
            for line in asm_lines:
                line = line.strip()  # 去除前后空白
                if line:
                    tmp += utils.standard_asm_code(line)
                    tmp +="\n"
            return tmp
        except Exception as e:
            print(f"Error while checking asm: {e}")


    @staticmethod
    def x64_pile_driver(asm_code,SP_ArchSpec = None):
        eh_frame_hdr_seg = idaapi.get_segm_by_name('.eh_frame')
        global _asmed
        tmp =[]
        ea = idaapi.get_screen_ea()
        curr_addr = ea
        global leng
        #print("222222")
        # a = utils.get_op_type(ea, 0)
        #print("111111")
        # b = utils.get_op_type(ea,2)
        # print("333333")
        DisplacementSizeType=utils.get_displacement_size_type(ea)
        # print(f"a----->> {DisplacementSizeType}-->>{type(DisplacementSizeType)}")
        # print("444444")
        old_asm_code,leng = utils.GetMnem(ea)    #lk
        old_asm_code = utils.standard_asm_code(old_asm_code)

        _asm_start = f"jmp {hex(eh_frame_hdr_seg.start_ea - ea)}"

        #print(f"op------>> {old_asm_code},地址是----{hex(ea)},长度为--->> {leng}\n")
        if leng<5:
            while (1):
                next_addr = idc.next_head(curr_addr)
                next_code,next_len = utils.GetMnem(next_addr)        #lk
                leng += next_len
                #规范一下汇编代码
                next_code = utils.standard_asm_code(next_code)
                #用于分隔命令
                old_asm_code += "\n"
                old_asm_code += next_code
                #print(f"next_code .......>>>>>>{next_code},type------>>> {type(next_code)}")
                curr_addr = next_addr
                if leng >=5:
                    break

        # print(f"  _asm_start---------{_asm_start},ia --->> {ea}")

        utils.insert_asm_code(ea, _asm_start, 0, 0,SP_ArchSpec = SP_ArchSpec)


        next_addr = idc.next_head(curr_addr)
        #print(f"next_addr------->>>>> {hex(next_addr)},---->>{next_addr-curr_addr}")
        #汇编桩功能代码，汇编覆盖掉的原来的指令，最后进行拼接
        assembled_string,length = utils.assemble(asm_code,SP_ArchSpec = SP_ArchSpec)
        old_asmed_code, leng_old = utils.assemble(old_asm_code, eh_frame_hdr_seg.start_ea + length,SP_ArchSpec = SP_ArchSpec)

        assembled_string += old_asmed_code
        length = len(assembled_string)
        #汇编最后的jmp代码，用于跳转回原来的执行流
        tmp1,tmp2 = utils.assemble(f"jmp {hex(next_addr - eh_frame_hdr_seg.start_ea - length)}",SP_ArchSpec = SP_ArchSpec) #到这了
        #print(f"--tmp1 ----->>> {tmp1}\n")

        assembled_string += tmp1
        # print(f"assembled_string------->>>> {assembled_string}\n")

        #patch to eh_frame
        utils.patch_code(eh_frame_hdr_seg.start_ea, assembled_string)

    @staticmethod
    def get_displacement_size_type(ea):
        try:

            insn = idaapi.insn_t()
            if not idaapi.decode_insn(insn, ea):
                return None

            # 定义数据类型映射
            dtype_map = {
                idaapi.dt_byte: 'byte',
                idaapi.dt_word: 'word',
                idaapi.dt_dword: 'dword',
                idaapi.dt_qword: 'qword',
                idaapi.dt_tbyte: 'tbyte',
                idaapi.dt_float: 'float',
                idaapi.dt_double: 'double',
                idaapi.dt_packreal: 'packed real',
                idaapi.dt_code: 'code',
                idaapi.dt_void: 'void',
                idaapi.dt_fword: 'fword',
                idaapi.dt_byte16: '16-byte',
            }


            imm_operand = None
            displ_operand = None
#判断参数类型是一个立即数和一个[ebp+0x10]的形式
            for opnd in insn.ops:
                if opnd.type == idaapi.o_imm:
                    imm_operand = opnd
                elif opnd.type == idaapi.o_displ:
                    displ_operand = opnd

            if  displ_operand:
                displacement_size_type = dtype_map.get(displ_operand.dtype, 'unknown')
                #print(f"Displacement size type: {displacement_size_type}")
                displacement_size_type += " ptr "
                return displacement_size_type

            return None

        except Exception as e:
            print(f"Error: {e}")
            return None





    @staticmethod
    def extract_immediate_number(operand):

        numbers = re.findall(r'\d+', operand)

        if len(numbers) != 1:
            raise ValueError(f"Expected exactly one number but found: {numbers}")

        return numbers[0]
    @staticmethod
    def get_op_type(ea,opnd_index):
        try:
            insn = idaapi.insn_t()
            if not idaapi.decode_insn(insn, ea):
                return None

            # Get the operand type
            operand = insn.ops[opnd_index]
            op_type = operand.type
            print(f"op_type---->> {op_type}")
            # Map operand types to human-readable strings
            type_map = {
                idaapi.o_reg: 'register',
                idaapi.o_imm: 'immediate',
                idaapi.o_mem: 'memory',
                idaapi.o_phrase: 'phrase',
                idaapi.o_displ: 'displacement',
                idaapi.o_far: 'far',
                idaapi.o_near: 'near'
            }

            # Return the description of the operand type
            operand_details = type_map.get(op_type, 'unknown')
            print(f"Operand details------->>>{operand_details}")
            return operand_details
        except Exception as e:
            print(f"error!!! ---->>>{e}")



    @staticmethod
    def extract_register(operand):
        pattern = r'\b[A-Za-z]{3,4}\b'
        try:
            match = re.search(pattern, operand)
            if match:
                return match.group()
            else:
                return None
        except Exception as e:
            print(f"An error occurred while extracting the register name: {e}")
            return None

    @staticmethod
    def standard_asm_code(asm_code_line):
        #去掉分号及其后面的内容就是注释，会干扰汇编器
        if ';' in asm_code_line:
            asm_code_line = asm_code_line.split(';')[0].strip()

        if 'retn' in asm_code_line:
            asm_code_line = asm_code_line[:-1]
        #检查是否有带h或H的十六进制数并替换成0x格式
        if 'h' in asm_code_line.lower():
            asm_code_line = re.sub(r'([0-9a-fA-F]+)[hH]', r'0x\1', asm_code_line, flags=re.IGNORECASE)

        return asm_code_line

    @staticmethod#Replace the symbol with a specific value
    def ReplaceSymbolValue(instruction,num):

        pattern = r"\[([a-zA-Z0-9]+)\+([a-zA-Z0-9_]+)\]"  # 匹配如 [rbp+s] 或 [rsp+var_10] 这样的模式
        match = re.search(pattern, instruction)

        if match:

            base_register = match.group(1)
            offset = match.group(2)

            # print(f"匹配到的寄存器: {base_register}")
            # print(f"匹配到的偏移量: {offset}")

            updated = f"[{base_register}{hex(num)}]"

            updated_instruction = instruction.replace(match.group(0), updated)

            # print("更新后的操作数:", updated)

            return updated
        else:
            print("没有找到匹配项")

    @staticmethod
    def Ret_Minus_Num(num):
        print("之前    int 类型-->> ", num)
        if num > 0x7fffffffffffffff:  # 2^63 - 1
            num = num - 0x10000000000000000  # 2^64
        else:#说明是32位的
            print("---=-==走到这里了")
            num = num - (1 << 32)
        print("之后int 类型-->> ",num)
        return num
    @staticmethod
    def assemble(asm_code,addr = 0,flags = True,arch = KS_ARCH_X86,mode = KS_MODE_64, syntax = KS_OPT_SYNTAX_INTEL,SP_ArchSpec = None):

        if SP_ArchSpec is not None:
            arch = SP_ArchSpec.arch
            mode = SP_ArchSpec.mode
            syntax = SP_ArchSpec.syntax
        else:
            print(f"Failed to get schema information. ")
            return None
        ks = Ks(arch, mode)

        ks.syntax = syntax
        try:
            print(f"adm_code-----boring！！-->>> {asm_code}")
            assembled_code, count = ks.asm(asm_code, addr,flags)
        except Exception as e:
            print(f"An error occurred in assembly conversion machine code. : {e}")
            pass
        length = len(assembled_code)

        return (assembled_code,length)
    @staticmethod
    def get_byte(leng,ea):
        for i in range(leng):
            tmp = []
            try:
                byte_vaule = idc.get_wide_byte(ea)
            except Exception as e:
                print(f"An error occurred while reading memory bytes: {e}")
                pass
            tmp.append(byte_vaule)
            print(f"tmp[]---->>> {tmp},type ----->>> {type(tmp)}")
            ea += 1

        return bytes(tmp)


    @staticmethod
    def patch_code(ea,assembled_string,asm_code=None):

        if assembled_string is not None:
            try:
                idaapi.patch_bytes(ea,assembled_string)
            except Exception as e:
                print(f"An error occurred while modifying the program machine code: {e}")
                pass

            if asm_code is not None:

                print(f"\nInserted at 0x{ea:X}: {asm_code}\nThe length is {len(assembled_string)}\n")

            else:

                print(f"\nInserted at 0x{ea:X}: {assembled_string}\nThe length is {len(assembled_string)}\n")
        else:

            print("Failed to assemble the code.")

    @staticmethod
    def GetMnem(ea):
#目前可以正确处理 call    _memset、 lea     rax, [rbp+s]、jmp     sub_4021F0、 lea     rdi, aNowYouCanMakeY
      try:
        order = None
        passive_0 = None
        passive_1 = None
        off = None
        # ea_addr = idc.next_head(ea)
        ea_code = idc.GetDisasm(ea)
        print(f"ea_code---->>> ",ea_code)
        ea_len = idc.create_insn(ea)
        ############################################################
        insn = ida_ua.insn_t()
        idaapi.decode_insn(insn, ea)
        mnemonic = ida_ua.print_insn_mnem(ea)
        operand = ida_ua.print_operand(ea, 1)
        print("operand ---111->> ", operand)

        ############################################################


        #print(f"ea_code .......>>>>>>{ea_code},type------>>> {type(ea_code)}")
        if any(keystring in ea_code for keystring in ["call", "j"]):
            order = 0
        elif ("push" in ea_code and "[" in ea_code and "]" in ea_code):
            DisplacementSizeType = utils.get_displacement_size_type(ea)
            if idc.get_operand_type(ea, 0) == 4:  # push [rbp+var_14]
                passive_0 = utils.Ret_Minus_Num(idc.get_operand_value(ea, 0))
                print(f"passive_0------>>>>>> {passive_0}")
            order = 0

        elif("lea" in ea_code or "mov" in ea_code or "cmp" in ea_code):

            operand = ida_ua.print_operand(ea, 1)   #取第二个参数主要是为了处理lea     rdi, aNowYouCanMakeY
            match  = re.search(r'[0-9A-Fa-f]{16}', operand)
            if match is None:
                match  = re.search(r'[0-9A-Fa-f]{8}', operand)      #兼容32位
            print(f"match------------------------------------------>>> {match}")
            if match is not None:
                order = 1
            elif("[" in ea_code and "]" in ea_code):
                #判断是否需要word ptr
                DisplacementSizeType = utils.get_displacement_size_type(ea)
                #进一步确认操作数是否是使用寄存器和位移的寻址操作
                if idc.get_operand_type(ea, 1) == 4:        #mov     eax, [rbp+var_14]
                    passive_1 = utils.Ret_Minus_Num(idc.get_operand_value(ea, 1))
                    #print(f"passive_1---->>> ",passive_1)

                elif idc.get_operand_type(ea, 0) == 4:          #mov     [rbp+var_14], eax
                    passive_0 = utils.Ret_Minus_Num(idc.get_operand_value(ea, 0))
                    #print(f"passive_0---->>> ", passive_0)
                order = 1
                #print("带具体数值的反汇编指令:", hex(a), "类型是", type(a),"passive-->>",passive,"类型是",type(passive))
            else:
                pass
        elif "large" in ea_code:
            ea_code = ea_code.replace("large","")       #mov     eax, large gs:14h
        elif "offset" in ea_code and "$" in ea_code:
            order = 1
            cur = ea#ststop
#order 为None说明是普通指令，直接使用ea_code，为0说明是call或者j，为1说明是cmp、mov、lea。  order在这里实际上代表第几个操作数
        if order is not None:           #push    [ebp+var_10]  ------>>>> push dword ptr  [ebp-0x10]
            if order ==  0:
                mnemonic = ida_ua.print_insn_mnem(ea)
                if passive_0 is not None:
                    match_st = utils.ReplaceSymbolValue(ea_code, passive_0)
                    print(f"DisplacementSizeType-------------??---->>{DisplacementSizeType}")
                    if DisplacementSizeType is not None:
                        match_st = DisplacementSizeType + match_st
                        DisplacementSizeType = None
                    match_st = " " + match_st
                    mnemonic += match_st

                else:
                    insn = ida_ua.insn_t()
                    idaapi.decode_insn(insn, ea)
                    # mnemonic = ida_ua.print_insn_mnem(ea)
                    operand = ida_ua.print_operand(ea, order)
                    print("operand --22-->> ",operand)
                    match  = re.search(r'[0-9A-Fa-f]{16}', operand)
                    match_st = ' 0x' + format(int(match.group(), 16),'X')
                    mnemonic += match_st
            elif order == 1:
                tmp = 0
                insn = ida_ua.insn_t()
                idaapi.decode_insn(insn, ea)
                mnemonic = ida_ua.print_insn_mnem(ea)
                while(tmp <= order):
                    operand = ida_ua.print_operand(ea, tmp)
                    #print("operand------>>>",{operand})
                    if tmp == 0:
                        if passive_0 is None :
                            try:
                                match_st = utils.extract_register(operand)
                            except Exception as e:
                                print(f"An error occurred while processing the first operand as a register: {e}")
                                pass
                        else :

                            match_st = utils.ReplaceSymbolValue(ea_code, passive_0)
                            if DisplacementSizeType is not None:
                                match_st = DisplacementSizeType + match_st
                                DisplacementSizeType = None
                            passive_0 = None

                        match_st = " "+ match_st +","

                    elif tmp == 1 :
                        if passive_0 is None and passive_1 is None:
                            try:

                                match  = re.search(r'[0-9A-Fa-f]{16}', operand)
                                match_st = ' [0x' + format(int(match.group(), 16),'X')+"]"
                            except:
                                match_st = utils.extract_register(operand)
                                if match_st is None:
                                    match_st = utils.extract_immediate_number(operand)


                        elif passive_1 is not None:
                            match_st = utils.ReplaceSymbolValue(ea_code, passive_1)
                            if DisplacementSizeType is not None:
                                match_st = DisplacementSizeType + match_st
                                DisplacementSizeType = None
                            passive_1 = None

                    mnemonic += match_st
                    tmp+=1
        #    print(f"insn----->> {insn},mnemonic --->> {mnemonic}>{type(mnemonic)},operand ---->> {operand}=={type(operand)},, \nmatch----{match.group()}\nmatch_string = {match_st}\ncomp --->>{CompMnemonic}")
            print(f"mnemonic ------------------>>>{mnemonic}<<")
            return (mnemonic,ea_len)
        # print(f"ea_code -----before_ret-->>>{ea_code}<<")
        return (ea_code,ea_len)
      except Exception as e:
          print(f"An error occurred while obtaining the mnemonic. : {e}")
          pass
    @staticmethod
    def insert_asm_code(ea,asm_code,base_addr = 0,flags = 1,SP_ArchSpec = None):


        assembled_string, length = utils.assemble(asm_code, base_addr,SP_ArchSpec = SP_ArchSpec)

        # print(f"assembled_11111---->> {assembled_string} type-->> {type(assembled_string)},count ---->> {length}")
        # if flags:
        #     length+=len(_asmed)
        #     assembled_string+=_asmed
        # else:
        #     assembled_string = assembled_string.ljust(leng, b"\x90")
        # print(f"assembled_222222---->> {assembled_string} type-->> {type(assembled_string)},count ---->> {length}")

        utils.patch_code(ea, assembled_string, asm_code)
